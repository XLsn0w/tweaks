struct NEPPalette {
    UIColor *background;
    UIColor *primary;
    UIColor *secondary;
    UIColor *detail;
};